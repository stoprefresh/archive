
public class StringOutput {

	public static void main(String[] args) {
		// Examine the code and add what you expect the output to be in each comment.
		// Then run the code.
		
		// Expected: 
		System.out.println("snow " + " ball");
		
		// Notice the print() statement.
		// Expected: 
		System.out.print("I could use some space\n\n");
		
		int tensVal = 9;
		int onesVal = 3;
		// Expected: 
		System.out.println("Concatenated number is " + tensVal + onesVal);
		
		// Expected: 
		System.out.println(tensVal + onesVal + " is another number");

	}

}
