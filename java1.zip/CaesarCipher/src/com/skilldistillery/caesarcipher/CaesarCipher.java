package com.skilldistillery.caesarcipher;

public class CaesarCipher {
  
  public String encrypt(String text, int shift) {
    String result = null;
    // Encryption logic here
    return result;
  }

  public String decrypt(String text, int shift) {
    String result = null;
    // Decryption logic here
    return result;
  }
  
  private char encryptChar(char toEncrypt, int shift) {
    char encrypted = '\u0000';
    return encrypted;
  }

  private char decryptChar(char toDecrypt, int shift) {
    char decrypted = '\u0000';
    return decrypted;
  }

}
