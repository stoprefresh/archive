package com.skilldistillery.inheritance.drills;

public class EmployeeApp {

  public static void main(String[] args) {
    EmployeeApp app = new EmployeeApp();
    app.run();
  }
  
  private void run() {
    Person pers = null;
    // Create a Person object and assign it to pers. Give the person a firstName,
    // lastName, and age using either the constructor or setters.
    
    // Call getInfo() and print the Person's information to the screen.
    
    Employee emp2 = null;
    // Create an Employee object using the five-argument constructor, and 
    // assign it to emp2.
    
    // Call getInfo() and print the Employee's information to the screen.
        
  }

}
