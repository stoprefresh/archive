package com.skilldistillery.interfaces.solutions.shapes;

public interface Drawable {
  void draw();
}
