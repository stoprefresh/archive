package com.skilldistillery.interfaces.solutions.shapes;

public interface ThreeDPrintable1 extends Drawable {
  void threeDPrint();
}
