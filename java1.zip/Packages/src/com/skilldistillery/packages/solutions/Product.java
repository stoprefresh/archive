package com.skilldistillery.packages.solutions;

public class Product {

}
