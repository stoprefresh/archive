package com.skilldistillery.polymorphism.examples;

public class SuperStatic {
  static String staticField = "SuperStatic";
  
  static void staticMethod(String data) {
    System.out.println("SuperStatic.staticMethod " + data);
  }
}
