package com.skilldistillery.unittesting.labs;

public class Calculator {
  
  public int add(int first, int second) {
    return -1;
  }
  
  public int subtract(int first, int second) {
    return -1;
  }
  
  public int multiply(int first, int second) {
    return -1;
  }
  
  public int divide(int numerator, int denominator) {
    return -1;
  }
  
  public double divide(double numerator, double denominator) {
    return -1;
  }
  
}
