package com.skilldistillery.enums.drills;

public class DayMethods {

  public static void main(String[] args) {
    // Iterate through the Day constants, printing each Day name.

    // If the name contains the letter R, add a "*" next to it.
  }

}
