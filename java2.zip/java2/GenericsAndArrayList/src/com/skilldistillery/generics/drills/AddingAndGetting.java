package com.skilldistillery.generics.drills;

import java.util.ArrayList;

public class AddingAndGetting {

  public static void main(String[] args) {
    AddingAndGetting ag = new AddingAndGetting();
    ag.run();
  }
  
  private void run() {
    ArrayList<String> strings = new ArrayList<>();
    
    // Output the list's size.
    
    // Add first names of several of your classmates.
   
    // Output the list's size again.
    
    // Use a for loop and get(index) to iterate through the list and print each name in uppercase letters.
   
    outputLastItem(strings);  // Stretch goal: Finish the method below.
     
  }
  
  private void outputLastItem(ArrayList<String> list) {
    // Finish this method to output the last item in the list in lowercase.
  }

}
