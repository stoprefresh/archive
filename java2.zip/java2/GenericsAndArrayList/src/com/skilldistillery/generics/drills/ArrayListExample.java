package com.skilldistillery.generics.drills;

public class ArrayListExample {

  public static void main(String[] args) {
    ArrayListExample ex = new ArrayListExample();
    ex.run();
  }

  private void run() {
    // Declare and instantiate an ArrayList to hold Strings. 
    // Use the type argument <String> in the constructor call.
   
    // Declare and instantiate an ArrayList to hold Double objects. 
    // This time use the <> shortcut in the constructor call.
    
    // Try to declare an ArrayList to hold double primitives (not Double objects). What happens?

    // Now try declaring an ArrayList without type arguments.
    
    
    // What is the warning Eclipse gives you?
    
    // What combinations of <> and <String> can you put on either side of the =, and still have the code compile?
    
  }

}
