package com.skilldistillery.innerclasses.drills;

import java.time.*;

public class InstanceInitalizerDrill {

  public static void main(String[] args) {
    // Paste the anonymous Runnable instantiation here
     
    // Call run() on the instance to see what LocalDateTime and 
    // Duration print.

  }

}
