package com.skilldistillery.innerclasses.drills;

public class OuterUsage {

  public static void main(String[] args) {
    Outer out = new Outer();
    out.aMethod();
  }

}
