package com.skilldistillery.junit5.solutions;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AccountTests {

  @Test
  void test() {
    fail("Not yet implemented");
  }

}
