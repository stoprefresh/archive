package com.skilldistillery.lambdas.drills;

public class UsingPredicate {

  public static void main(String[] args) {
    // Declare and define a Predicate<String> that tests whether
    // an input String ends with "!!"
    
    // Declare and define a Predicate<String> that tests whether
    // an input String is all uppercase.

    // Test your two Predicates by calling their test methods with some Strings.

  }

}
