package com.skilldistillery.lambdas.solutions;

public interface IntegerChecker {
  boolean test(Integer i);
}
