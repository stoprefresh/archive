package com.skilldistillery.advancedarrays.drills;

import com.skilldistillery.advancedarrays.drills.PopStar;

public class ArrayOfObjects {

  public static void main(String[] args) {
    // Instantiate an Array to hold PopStar objects.
    
    // Create PopStar instances and add them to the array.
    
    // Call the method allSing, passing your array.
  }
  
  public static void allSing(PopStar[] stars) {
    // Loop through the array and call each PopStar's sing() method.

  }

}
