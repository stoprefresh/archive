package drills;

public class ArrayDeclare {

  public static void main(String[] args) {
    // Declare a variable for an array of String objects to hold the name of each weekday.

    // Declare a variable to hold letter grades for each of a student's six classes.

    // Declare a variable to hold the average monthly precipitation for a year.

  }

}
