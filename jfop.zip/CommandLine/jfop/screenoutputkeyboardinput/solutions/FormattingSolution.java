
public class FormattingSolution {

	public static void main(String[] args) {
		/*Change the String literal to print
		  
		  \\ His name was "Robert Paulson."  
		  You cry now. //
		  
		  Make sure it is a single String literal.
		 */
		System.out.println("\\\\ His name was \"Robert Paulson\". \nYou cry now. //");
	}

}
