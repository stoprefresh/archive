package com.skilldistillery.datatypes.drills;

public class FloatValues {

  public static void main(String[] args) {
    // Copy f1 to f8 in text here. Comment out values that do not work.

  }

}
