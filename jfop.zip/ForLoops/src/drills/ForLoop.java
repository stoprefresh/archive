package drills;

public class ForLoop {

  public static void main(String[] args) {
    // Write a for loop to print the numbers 1 to 10 to the screen.

    // Write the same loop with the loop control variable starting at 0.

  }

}
