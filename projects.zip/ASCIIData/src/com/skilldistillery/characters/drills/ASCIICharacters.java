package com.skilldistillery.characters.drills;

public class ASCIICharacters {

	public static void main(String[] args) {

		char c = 65021;
		char i =  65535;
		System.out.println(c);
		System.out.println(i);
//		for (char i = 0; i <= 65534; i++) {
// 		
//			System.out.println("" + (int)i + " - " + i);
//		}

	}

}
// 