package com.skilldistillery.characters.drills;

public class TEPITW {

		public static void main(String[] args) {
			
			
			System.out.println();
		}
}
