package com.skilldistillery.advancedarrays.drills;

public class PopStar {
  public String name, lyrics;
  public int age;
  public boolean alive;
  public void sing() {
    // Have the PopStar print their name to the screen, as part of some kind of lyric.
    // Be creative.
   System.out.println(lyrics);
   System.out.println();
   System.out.println();
  }
}


