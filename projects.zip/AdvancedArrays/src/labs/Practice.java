package labs;

public class Practice {

}
