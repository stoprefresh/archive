package practice;

public class PracticeStuff {

	public static void main(String[] args) {
		
		int arrayD [][] = new int[3][3];
		
		
		
		
		
		
		
		
//		for (int outer = 1; outer <= 10; outer++) {
//
//			for (int inner = 1; inner <= 10; inner++) {
//				int product = outer * inner;
//				System.out.print(product + "\t");
//			}
//			System.out.println();
//		}
		
		System.out.println();
		System.out.println("-------------------------");
		System.out.println();

		for (int outer = 0; outer <= 9; outer++) {

			for (int inner = 0; inner <= 9; inner++) {
				int product = inner;
				System.out.print(product + " ");
			}
			System.out.println();
		}

	}
}
