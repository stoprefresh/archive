package drills;



public class ArrayDeclare {

  public static void main(String[] args) {
	  
	  int myAge = 82;
	  String myFirstName = "Miguel";
	  
    // Declare a variable for an array of String objects to hold the name of each weekday.
	  String weekday[] = new String[7];
	 
    // Declare a variable to hold letter grades for each of a student's six classes.
	  char letterGrade[] = new char[6];
    // Declare a variable to hold the average monthly precipitation for a year.
	  double avgPrecip[] = new double[12];
	  
	  weekday[0] = "Monday";
	  weekday[1] = "Tuesday";
	  
	  

  }

}
