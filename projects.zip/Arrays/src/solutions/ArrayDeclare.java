package solutions;

public class ArrayDeclare {

	public static void main(String[] args) {
		// Declare a variable for an array of String objects to hold the name of each weekday.
		String[] weekdays;
		
		// Declare a variable to hold letter grades for each of a student's six classes.
		char grades[];
		
		// Declare a variable to hold the average monthly precipitation for a year.
		double [ ] avgMonthlyPrecip;
		
		// NOTE: as you can see above, whitespace does not matter. 
	}

}
