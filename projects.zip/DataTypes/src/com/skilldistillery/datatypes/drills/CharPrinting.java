package com.skilldistillery.datatypes.drills;

public class CharPrinting {

  public static void main(String[] args) {
    char variable = 'A';
    System.out.println(variable);
    System.out.println(variable + 30);
    // Add the line System.out.println(variable + 1); to main(). 
    // What is the output?
    // Based on its output, what does the `+` operator appear to do?
  
  }

}
