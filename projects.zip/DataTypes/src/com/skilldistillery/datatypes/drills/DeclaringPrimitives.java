package com.skilldistillery.datatypes.drills;

public class DeclaringPrimitives {

  public static void main(String[] args) {
    // Declare a byte variable and assign the value 128. What happens? Assign it a valid value.
    byte i;
    // Create a switch statement for your variable.
    // Have a case for each of the values 127, -128, 0, 'A', 128, '\u0000'.
    // Which values cause compiler errors?
    
    int c;
    // Declare a int variable and assign it a value.
    
    // Again create a switch statement.
    // Have a case for each of the values 127, -128, 'A', 128, '\u0000'.

  }

}
