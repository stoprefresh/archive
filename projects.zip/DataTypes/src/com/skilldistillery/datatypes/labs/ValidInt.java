package com.skilldistillery.datatypes.labs;

public class ValidInt {

	public static void main(String[] args) {
		
		
		int validInt = 1;
		
		int longInt = validInt;
		
		validInt = longInt;
		
		System.out.println(validInt);
	}
	
	
}
