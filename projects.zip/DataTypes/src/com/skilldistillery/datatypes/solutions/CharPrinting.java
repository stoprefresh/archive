package com.skilldistillery.datatypes.solutions;

public class CharPrinting {

  public static void main(String[] args) {
    char variable = 'A';
    System.out.println(variable);
    System.out.println(variable + 1); // This actually produces an int
  }

}
