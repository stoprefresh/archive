package com.skilldistillery.encapsulation.drills;

public class AccessMods {

	
	public static void main(String[] args) {
		
		
		
		
	}
}
