package com.skilldistillery.encapsulation.drills;

public class Dog {

}
