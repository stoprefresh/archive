public class TestClass {
	public static void main(String[] args) {
		
		int numberOfLetters = switch (fruit) {
	    case PEAR -> 4;
	    case APPLE, MANGO, GRAPE -> 5;
	    case ORANGE, PAPAYA -> 6;
	}
		
	}
}
