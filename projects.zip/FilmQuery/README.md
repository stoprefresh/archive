# Film Query Project

##### Programmer Info.
###### Author *Miguel Marsiglia*
###### Start Date *June 24, 2019*


#### Skill Distillery - Weekend Homework

This Program allows a user to search through a database of films. Movies can be searched by key word
or by ID.
The program will then print out the Title, Year Released, Rating, Description and Language.
The credits will follow with primary actors attributed to the film.

##### Technologies Used

 1. github
 2. Java
 3. Eclipse
 4. UML


###### Lessons Learned

 *Searching through a database with a prepared statement and getting the correct syntax for MySQL
