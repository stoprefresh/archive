package drills;

public class ForLoop {

  public static void main(String[] args) {
    // Write a for loop to print the numbers 1 to 10 to the screen.
	
	  
	  
//	for (start; check condition; iterate)
	  
//	  for(int i = 0; i < 11; i++) {
//		  System.out.println(i);
//	  }
	 
	  for(int i = 0; i < 10; i++) {
		  System.out.println(i + 1);
	  }
	  
	  
	  
    // Write the same loop with the loop control variable starting at 0.

  }

}
