package project;

public class FizzBuzz {

}
