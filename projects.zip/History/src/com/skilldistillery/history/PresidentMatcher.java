package com.skilldistillery.history;

public interface PresidentMatcher {

  boolean matches(President pres, String string);
  
}